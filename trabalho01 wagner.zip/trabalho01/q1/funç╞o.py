def contar_palavra(frase, palavra):
    # Converte tudo para minúsculas e divide em palavras
    palavras_frase = frase.lower().split()
    # Conta quantas vezes a palavra aparece
    return palavras_frase.count(palavra.lower())

# Programa principal
frase = input("Digite uma frase: ")
palavra = input("Digite uma palavra para buscar: ")

quantidade = contar_palavra(frase, palavra)
print("A palavra aparece", quantidade, "vez(es).")