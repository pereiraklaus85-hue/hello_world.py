def verificar_par_impar(numero):
    """
    Recebe um número inteiro e retorna se ele é 'Par' ou 'Ímpar'.
    """
    if numero % 2 == 0:
        return "Par"
    else:
        return "Ímpar"