def autenticar(usuarios, usuario, senha):
    """
    Verifica se o usuário e a senha estão corretos.
    Retorna True se a autenticação for bem-sucedida, False caso contrário.
    """
    if usuarios.get(usuario) == senha:
        return True
    else:
        return False