from funcoes_bolsa import (
    autenticar, aplicar_desconto, verificar_acao,
    verificar_idade, calcular_imc, classificar_imc,
    aplicar_imposto, dividir
)





# 1. Login
email = input("Digite o email: ")
senha = input("Digite a senha: ")
print("Login bem-sucedido!" if autenticar(email, senha) else "Email ou senha incorretos.")

# 2. Desconto
preco = float(input("\nDigite o preço do produto: "))
print(f"Preço com desconto: R$ {aplicar_desconto(preco):.2f}")

# 3. Verificar ação
valor_acao = float(input("\nDigite o valor da ação: "))
print(verificar_acao(valor_acao))

# 4. Verificar idade
idade = int(input("\nDigite sua idade: "))
print(verificar_idade(idade))

# 5. Calcular IMC
peso = float(input("\nDigite seu peso (kg): "))
altura = float(input("Digite sua altura (m): "))
imc = calcular_imc(peso, altura)
print(f"Seu IMC é {imc:.2f} ({classificar_imc(imc)})")

# 6. Aplicar imposto
preco_produto = float(input("\nDigite o preço do produto para aplicar imposto: "))
print(f"Valor final com imposto: R$ {aplicar_imposto(preco_produto):.2f}")

# 7. Try...Except exemplos
print("\n=== Tratamento de Erros ===")
try:
    n1 = float(input("Digite o primeiro número: "))
    n2 = float(input("Digite o segundo número: "))
    print(f"Resultado da divisão: {dividir(n1, n2)}")
except ValueError:
    print("Erro: você digitou um valor que não é número.")