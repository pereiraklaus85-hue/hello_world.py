
# 1. Função de login
def autenticar(email, senha):
    return email == 'admin' and senha == 'admin'


# 2. Função de desconto
def aplicar_desconto(preco):
    return preco * 0.9  # desconto de 10%


# 3a. Função para verificar se ação está cara ou barata
def verificar_acao(valor):
    if valor > 150.99:
        return "Ação está cara! Compre com cuidado."
    else:
        return "Ação está barata!"


# 4. Função para verificar maioridade
def verificar_idade(idade):
    if idade >= 18:
        return "Maior de idade"
    else:
        return "Menor de idade"


# 5a. Função para calcular IMC
def calcular_imc(peso, altura):
    return peso / (altura ** 2)


# 5b. Função para classificar IMC
def classificar_imc(imc):
    if imc < 18.5:
        return "Abaixo do peso"
    elif imc < 25:
        return "Peso normal"
    else:
        return "Acima do peso"


# 6. Função para aplicar imposto
def aplicar_imposto(preco):
    return preco * 1.15  # adiciona 15% de imposto


# 7. Função para dividir com tratamento de erro
def dividir(a, b):
    try:
        return a / b
    except ZeroDivisionError:
        return "Erro: divisão por zero não é permitida."